package com.blog.controller.admin;

import com.blog.dao.UserDao;
import com.blog.pojo.User;
import com.blog.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
@RequestMapping("/admin")
public class RegisterController {

    @Autowired
    private UserDao userDao;
    @Autowired
    private UserService userService;
    @RequestMapping("/toregister")
    public String toRegisterPage() {
        return "admin/register";
    }

    @RequestMapping("/reg")      //submit register
    public String register(User user){
        if(userService.register(user)>0){
            System.out.println("add success");
            return "admin/login";
        }else {
            return "admin/register";
        }

    }
}
