package com.blog;

import com.blog.dao.BlogDao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@SpringBootTest
class BlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
